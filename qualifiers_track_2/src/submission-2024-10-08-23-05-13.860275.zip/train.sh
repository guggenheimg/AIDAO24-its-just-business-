export PATH=/usr/conda/bin:$PATH
python train.py